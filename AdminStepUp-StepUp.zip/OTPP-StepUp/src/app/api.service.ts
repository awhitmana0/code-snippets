import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as config from '../../auth_config.json';
import { AuthService } from '@auth0/auth0-angular';


@Injectable({
  providedIn: 'root',
})
export class ApiService {
  constructor(
    private http: HttpClient,
    private auth:AuthService
  ) {}

  ping$(): Observable<any> {
    console.log(config.apiUri);
    return this.http.get(`${config.apiUri}/api/external`);
  }

  transferenciaServicio(transferencia){
    console.log("making the call to the Authorization Server (Formerly known as Auth0)");
    this.auth.getAccessTokenWithPopup({audience:'https://sample-otpp-server.com/',scope:'openid profile email admin:behalf_of',account_id:transferencia.account_id, ignoreCache:true}).subscribe({
      next: (res) => {
          //this.hasGetTokenError = false;
          console.log("A new token received from Auth0:")
          console.warn(JSON.stringify(res));
        },
        error: (res) => {
          //this.hasGetTokenError = true,
          console.log("SOMETHING WENT WRONG!");
          console.warn(JSON.stringify(res, null, 2).trim());
        }
      });
  }

}
