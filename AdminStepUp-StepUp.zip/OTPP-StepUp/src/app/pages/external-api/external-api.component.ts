import { Component } from '@angular/core';
import { AuthClientConfig } from '@auth0/auth0-angular';
import { ApiService } from 'src/app/api.service';
import { FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-external-api',
  templateUrl: './external-api.component.html',
  styleUrls: ['./external-api.component.css'],
})
export class ExternalApiComponent {
  responseJson: string;
  audience = this.configFactory.get()?.audience;
  hasApiError = false;
  transferForm = this.formBuilder.group({
    account_id: ''
  });
  constructor(
    private formBuilder: FormBuilder,
    private api: ApiService,
    private configFactory: AuthClientConfig
  ) {}

  pingApi() {
    this.api.ping$().subscribe({
      next: (res) => {
        this.hasApiError = false;
        this.responseJson = JSON.stringify(res, null, 2).trim();
      },
      error: () => this.hasApiError = true,
    });
  }

  onSubmit(): void {

    this.api.transferenciaServicio(this.transferForm.value);
   
  }

 
}
