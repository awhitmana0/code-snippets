
import { Container, Row, Col } from "reactstrap";
import Highlight from "../components/Highlight";
import Loading from "../components/Loading";
import { useAuth0, withAuthenticationRequired } from "@auth0/auth0-react";
import React, { useEffect, useState } from "react";

export const ProfileComponent = () => {
  const { user, isAuthenticated, getAccessTokenSilently } = useAuth0();
  const [userMetadata, setUserMetadata] = useState(null);

  return (
    <Container className="mb-5">
      <Row className="align-items-center profile-header mb-5 text-center text-md-left">
        <Col md={2}>
          <img
            src={user.picture}
            alt="Profile"
            className="rounded-circle img-fluid profile-picture mb-3 mb-md-0"
          />
        </Col>
        <Col md>
          <h2>{user.name}</h2>
          <p className="lead text-muted">{user.email}</p>
        </Col>
      </Row>
      <Row>
        <Highlight>{JSON.stringify(user, null, 2)}</Highlight>
      </Row>
      <Row>
        {user["https://lifelabs.ca/user/region_code"] === "Ontario" &&
        <div>
        <h2>
         Region: Ontario
         </h2>
          <img
        src={"https://geology.com/canada/ontario-map.gif"}
        alt="Ontario Map"
        className="img-fluid profile-picture mb-3 mb-md-0"
      /></div>
      } {user["https://lifelabs.ca/user/region_code"] === "BC" &&
      <div>
        <h2>
         Region: BC
         </h2>
          <img
        src={"https://geology.com/canada/british-columbia-map.gif"}
        alt="Ontario Map"
        className="img-fluid profile-picture mb-3 mb-md-0"
      /></div>
      
    }
      </Row>
    </Container>
  );
};

export default withAuthenticationRequired(ProfileComponent, {
  onRedirecting: () => <Loading />,
});
